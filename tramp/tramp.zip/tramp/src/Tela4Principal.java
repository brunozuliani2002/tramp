import javax.swing.*;

public class Tela4Principal {
    public JPanel JPTelaPrincipal;
    private JButton btnCarrosAlugados;
    private JButton btnCarrosVendidos;
    private JTextField txtCarro3;
    private JTextField txtCarro2;
    private JTextField txtCarro1;
    private JTextField txtCarro6;
    private JTextField txtCarro4;
    private JTextField txtCarro5;
}
